#include <iostream>
#include <stdio.h>
#include <string.h>
#include <mysql.h>

#include "teacher.h"
#include "administrator.h"

using namespace std;

int main()
{
    printf("hello world!\n");
    return 0;
}
